# Intelligence-Artificielle-UQAC-TP
Le projet est compilé avec la v100 de C++ disponible avec Visual Studio 2010
Il ne faut donc pas migrer le projet .vcxproj à l'ouverture
