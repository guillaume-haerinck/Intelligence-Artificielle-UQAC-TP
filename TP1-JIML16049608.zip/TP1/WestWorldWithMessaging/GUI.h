#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

namespace GUI
{
	void LoopSFML();
};